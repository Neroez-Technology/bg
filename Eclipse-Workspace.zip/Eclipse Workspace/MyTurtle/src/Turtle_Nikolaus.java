

import ch.aplu.turtle.*;
import java.util.Scanner;

public class Turtle_Nikolaus{

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        
        
        
		Turtle hans = new Turtle();
		
		hans.forward(50);
		hans.left(90);		
		hans.forward(50);
		hans.left(90);		
		hans.forward(50);
		hans.left(90);		
		hans.forward(50);
		hans.left(135);		
		hans.forward(71);
		hans.left(135);	
		hans.forward(50); 
		hans.left(135);
		hans.forward(71);
		hans.left(90);
		hans.forward(35);
		hans.left(90);
		hans.forward(35);
		hans.left(135);
		hans.forward(100); 
		hans.left(135);
		hans.forward(35);
		hans.left(90);
		hans.forward(35);
		hans.left(90);
		hans.forward(71);
		hans.left(135);
		hans.forward(50);
		hans.left(135);
		hans.forward(71);
		hans.left(135);
		hans.forward(50);
	}

}