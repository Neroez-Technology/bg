import javax.swing.*;

import java.util.Scanner;

class BMI_Console extends JPanel{
  public static void main ( String[] args ) throws InterruptedException{
	  
	  
	  
    double m = 0;
    double g = 0;
    
    
    System.out.println("Willkommen beim BMI Rechner");
    Thread.sleep(800);
    System.out.println("-------by S�ren------------");
    Thread.sleep(1000);
    
    
    do{
    	Scanner sm = new Scanner(System.in);
        System.out.print("Gib gebe dein Gewicht ein (kg): ");
        m = sm.nextDouble();
       
        Scanner sg = new Scanner(System.in);
        System.out.print("Gib gebe deine Gr��e ein (m): ");
        g = sg.nextDouble();
        
    }while ( g < 0.5 || g > 3 || m < 2 || m > 300);
    
    
   
    double bmi = m / Math.pow(g,2);
    
    System.out.println("Dein BMI ist "+ bmi);
    
       
     
    if ( bmi >= 18.5 && bmi <= 25){
      System.out.println("Du hast Normalgewicht");
      
    }
    if ( bmi > 17.0 && bmi < 18.5){
      System.out.println("Du hast leichtes Untergewicht");
      
    }
    if ( bmi > 16.0 && bmi < 17.0){
      System.out.println("Du hast m��iges Untergewicht");
      
    }
    if ( bmi < 16.0){
      System.out.println("Du hast starkes Untergewicht");
      
    }
    if ( bmi > 25.0 && bmi <= 30.0){
      System.out.println("Du hast Pr�adipositas");
      
    }
    if ( bmi > 30.0 && bmi <= 35.0){
      System.out.println("Du hast Adipositas Grad I");
      
    }
    if ( bmi > 35.0 && bmi <= 40.0){
      System.out.println("Du hast Adipositas Grad II");
     
    }
    if ( bmi > 40 ){
      System.out.println("Du hast Adipositas Grad III");
      
    }
    String zufrieden = "N.A.";
    Scanner zufrieden_s = new Scanner(System.in);
    System.out.println("Bist du zufrieden ? (j/n) :");
    zufrieden = zufrieden_s.next();
    System.out.println("TEST__Inhalt von String �zufrieden� :"+zufrieden);
    
    
    if (zufrieden == "j")
    	System.out.println("Sch�n!");
    
    if (zufrieden == "n")
    	System.out.println("ok! Das l�st sich �ndern ;)");
    	int grad_wunsch = 0;
    	Scanner wahl = new Scanner(System.in);
    	System.out.println("Weche Stufe m�chtest du errreichen ?");
    	System.out.println("--------------Auswahl---------------");
    	System.out.println("1 = leichtes Untergewicht");
    	System.out.println("2 = m��iges Untergewicht");
    	System.out.println("3 = starkes Untergewicht");
    	System.out.println("4 = Normalgewicht");
    	System.out.println("5 = Pr�adipositas");
    	System.out.println("6 = Adipositas Grad I");
    	System.out.println("7 = Adipositas Grad II");
    	System.out.println("8 = Adipositas Grad III");
    	System.out.println("-------------------------------------");
    	System.out.println("Bitte gebe die Nummer an (1-8) :");
    	grad_wunsch = wahl.nextInt();
    
    	String wahl_user;
    
    	switch (grad_wunsch) {
        case 1:  wahl_user = "leichtes Untergewicht";
                 break;
        case 2:  wahl_user = "m��iges Untergewicht";
                 break;
        case 3:  wahl_user = "starkes Untergewicht";
                 break;
        case 4:  wahl_user = "Normalgewicht";
                 break;
        case 5:  wahl_user = "Pr�adipositas";
                 break;
        case 6:  wahl_user = "Adipositas Grad I";
                 break;
        case 7:  wahl_user = "Adipositas Grad II";
                 break;
        case 8:  wahl_user = "Adipositas Grad III";
                 break;
        default: wahl_user = "Ung�ltiger Grad !";
                 break;
    	}
    
    	double bmi_neu = 0;
    	double m_ver�nderung = 0;
    	String faktor = "abnehmen";
    	m_ver�nderung = m;
    	System.out.println("Um " + wahl_user + " zu erreichen, musst du " + m_ver�nderung + " " +faktor);
    
  }  
}
/* do{
Scanner sm = new Scanner(System.in);
System.out.print("Gib gebe dein Gewicht ein: ");
String text_m = sm.next();
m = Double.parseDouble(text_m);
sm.close();
Scanner si = new Scanner(System.in);
System.out.print("Gib gebe deine Gr��e ein: ");
String text_i = si.next();
i = Double.parseDouble(text_i);
si.close();
}while ( i < 0.1);
*/

